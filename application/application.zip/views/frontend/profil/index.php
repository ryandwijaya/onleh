<div class="row">

	<div class="col-lg-12">
		<div class="about-top-content-wrapper">
			<div class="row row-30">
				<!-- About Image -->
				<div class="col-lg-6">
					<div class="about-image">
						<img src="<?= base_url() ?>assets/upload/images/profil/profil.jpg" class="img-fluid" alt="">
					</div>
				</div>

				<!-- About Content -->
				<div class="about-content col-lg-6">
					<div class="row">
						<div class="col-12">
							<h1>Nadhira Napoleon Pekanbaru</span></h1>
							<p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad aspernatur atque, beatae, blanditiis deserunt doloremque excepturi in itaque iusto, laudantium minus natus provident quo sunt voluptatibus? Ducimus illo ipsa quisquam.</p>
						</div>



					</div>
				</div>
			</div>
		</div>
	</div>


</div>
