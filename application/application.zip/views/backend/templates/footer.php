</div>
<footer class="dt-footer">
  Copyright  - <a href="http://wikidevia.digtive.id/" target="_blank"> Digtive</a>-  © 2019
</footer>
<!-- /footer -->
            </div>
            <!-- /site content wrapper -->

            


        </main>
    </div>
</div>
<!-- /root -->

<!-- Optional JavaScript -->
<script src="<?php echo base_url() ?>assets/backend/node_modules/jquery/dist/jquery.min.js"></script>
<script src="<?php echo base_url() ?>assets/backend/node_modules/moment/moment.js"></script>
<script src="<?php echo base_url() ?>assets/backend/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- Perfect Scrollbar jQuery -->
<script src="<?php echo base_url() ?>assets/backend/node_modules/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
<!-- /perfect scrollbar jQuery -->

<!-- masonry script -->
<script src="<?php echo base_url() ?>assets/backend/node_modules/masonry-layout/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo base_url() ?>assets/backend/node_modules/sweetalert2/dist/sweetalert2.js"></script>
<script src="<?php echo base_url() ?>assets/backend/js/functions.js"></script>
<script src="<?php echo base_url() ?>assets/backend/js/customizer.js"></script>
<script src="<?php echo base_url() ?>assets/backend/node_modules/chart.js/dist/Chart.min.js"></script>

<!-- Resources -->
<script src="<?php echo base_url() ?>assets/backend/node_modules/ammap3/ammap/ammap.js"></script>
<script src="<?php echo base_url() ?>assets/backend/node_modules/ammap3/ammap/maps/js/continentsLow.js"></script>
<script src="<?php echo base_url() ?>assets/backend/node_modules/ammap3/ammap/themes/light.js"></script>

<script src="<?php echo base_url() ?>assets/backend/node_modules/amcharts3/amcharts/amcharts.js"></script>
<script src="<?php echo base_url() ?>assets/backend/node_modules/amcharts3/amcharts/gauge.js"></script>

<script src="<?php echo base_url() ?>assets/backend/js/script.js"></script>
<script src="<?php echo base_url() ?>assets/backend/js/custom/charts/dashboard-default.js"></script>
<!-- Custom JavaScript -->
<script src="<?php echo base_url() ?>assets/backend/node_modules/datatables.net/js/jquery.dataTables.js"></script>
<script src="<?php echo base_url() ?>assets/backend/node_modules/datatables.net-bs4/js/dataTables.bootstrap4.js"></script>
<script src="<?php echo base_url() ?>assets/backend/js/custom/data-table.js"></script>

<script src="<?php echo base_url() ?>assets/backend/node_modules/sweetalert2/dist/sweetalert2.js"></script>
<script src="<?php echo base_url() ?>assets/backend/js/custom/sweet-alert.js"></script>

<script src="<?php echo base_url() ?>assets/backend/js/custom/apps/multiscale.js"></script>


<script>
$(function() {
var timeout = 5000; // in miliseconds (3*1000)

$('.hide-it').delay(timeout).fadeOut(200);
});

</script>


</body>

</html>
